package udemy;

public class Dowhile {
	public static void main(String[] args) {
		int a=12,b=100;
	 do{
			
			System.out.println(a++);
		
		} while(a<=b);
	 System.out.println("last"+""+a);
	}
	

}
