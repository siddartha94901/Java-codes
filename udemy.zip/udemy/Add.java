package udemy;

public class Add {
	public static void main(String[]args)
	{
		int a=1,b=33,c=13;
		int add=a+b+c;
		System.out.print(add);
	}

}
