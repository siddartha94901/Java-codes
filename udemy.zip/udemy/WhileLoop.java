package udemy;

public class WhileLoop {
	public static void main(String[] args) {
		
	int i=1,j=10;
	while(i<=j)
		{
		System.out.println(i++);
		}

}}
