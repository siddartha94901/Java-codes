package udemy;
import java.util.*;
public class ReverseNum {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter digits");
		int n= sc.nextInt();
	while(n>0)
			
		{
			int r=n%10;
			 n=n/10;
			System.out.println(r);
			
		}
	}

}
