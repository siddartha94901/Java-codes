package udemy;

public class ConditionalOpe {
	public static void main(String[] args) {
		int a=1,b=2,c=3;
		 if(a<b)
		 {
		 System.out.println(b);
	}
	}
}
