package udemy;

public class ObjectCreatin {

	public static void main(String[] args) {
		ObjectCreatin Siddu=new ObjectCreatin();
		System.out.print(Siddu);

	}
}
