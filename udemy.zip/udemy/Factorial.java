package udemy;
import java.util.*;
public class Factorial{
	public static void main(String[]args) {
		//Finding factorial for n number
		//5!=1x2x3x4x5
		Scanner sc=new Scanner(System.in);
		System.out.println("enter n value");
		int n=sc.nextInt();
		int Factorial=1;
		
		for(int i=1;i<=n;i++)
		{
			Factorial=Factorial*i;
			System.out.println(Factorial);
		}
		System.out.println("Factorial value of "+n+" is "+Factorial);
		
	}

}
