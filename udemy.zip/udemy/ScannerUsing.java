package udemy;
import java.util.*; //importing uti package for scanner
public class ScannerUsing {
public static void main(String[] args) {
	System.out.println("ADDITION OF 2 NUMBERS");
	Scanner s=new Scanner(System.in);
	System.out.println("ENTER A VALUE");
	int a=s.nextInt();
	System.out.println("ENTER B VALUE");
	int b=s.nextInt();
	int add=a+b;
	System.out.println("ADDITION OF TWO NUMBERS IS"+" "+add);
	
	/*
	 * Scanner used for to get input from keyboard and used new keyword for scanner
	 * object creation
	 */
}
}
