package udemy;

import java.util.*;
public class ArithmaticOperat {
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		long a=s.nextLong();
		long b=s.nextLong();
		
		System.out.println("add of two"+" num"+"   "+(a+b));
		System.out.println("sub of two"+" num"+"   "+(a-b));
		System.out.println("mul of two"+" num"+"   "+(a*b));
		System.out.println("div of two"+" num"+"   "+(a/b));
		System.out.println("reminder of two"+" num"+"   "+(a%b));
		
		
	}

}
