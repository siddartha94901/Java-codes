package udemy;

import java.util.*;

public class Count {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("enter digits");
		int Digit = sc.nextInt();
		int count = 0;

		while (Digit > 0) {

			Digit = Digit / 10;
			count++;
			System.out.println(count);
		}
	}
}
