package udemy;

public class Methods {
	int add() {
		int a = 12, b = 13, c = a + b;

		System.out.println(c);
		return c;
	}    //calling method from main method using obejct keyword

	public static void main(String[] args) {
		Methods sum = new Methods();
		sum.add();
		System.out.println(sum);
	}
}
