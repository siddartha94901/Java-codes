package udemy;

import java.util.*;//from util package i am using scanner function in this program


public class Nnumadd {
	public static void main(String[] args) {
		// sum of n numbers is
		// 1+2+3+...+n=sum
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter n value");
		int n = sc.nextInt();

		int sum = 0;

		for (int i = 1; i <= n; i++) {

			sum = sum + i;
			System.out.println(sum);
		}
		System.out.println("sum of "+n+ " is "+sum);

	}

}
