package Methods;

public class RectangleTest {
	public static void main(String[]args)
	{
	Rectangle r=new Rectangle();
	r.setLength(100);
	r.setBredth(393);
	r.Area();
	r.perimeter();
	//r.toString();
	System.out.println(r.getLength());
	System.out.println(r.getBredth());
	
	}
}
