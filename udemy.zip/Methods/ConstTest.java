package Methods;

public class ConstTest {
	
	public static void main(String[]args)
	{
		Const s=new Const(122);
			//System.out.print();
		System.out.println(s);
	}

}
