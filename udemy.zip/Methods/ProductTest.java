package Methods;

public class ProductTest {
	public static void main(String[]args)
	{
		Product pq=new Product();
		pq.getItemId();
		pq.getItemName();
		pq.setPrice(122);
		pq.setQty(6);
		pq.bill();
	}

}
