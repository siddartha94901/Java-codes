package Methods;

public class Const {
	private int a=12;
	
	public Const( int d)
	{
		a=d+12;
		System.out.println(a);
			
		}
	}


