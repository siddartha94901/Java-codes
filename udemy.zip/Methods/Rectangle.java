package Methods;

public class Rectangle {

	int length, bredth;

	public void setLength(int l) {
		length = l;
	}

	public void setBredth(int b) {
		bredth = b;
	}

	public int getLength() {
		return length;
	}

	public int getBredth() {
		return bredth;
	}

	public void Area() {
		int area = getLength() * getBredth();
		System.out.println(area);
	}
	public void perimeter()
	{
		int perimeter=2*(getLength()+getBredth());
		System.out.println(perimeter);
	}
	
}
