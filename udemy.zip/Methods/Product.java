package Methods;

public class Product {
	private String item_id = "Sidd";
	private String item_name = "Human";
	private int Price = 1;
	private int Quantity = 1;

	public void getItemId() {
		System.out.println("Sidd");
	}

	public void getItemName() {
		System.out.println("Human");
	}

	public void setPrice(int p) {
Price=p;
	}
	public void setQty(int q) {
		Quantity=q;
	}
public int bill() {
	int t=Price*Quantity;
	System.out.println(t);
	return t;
}
}
