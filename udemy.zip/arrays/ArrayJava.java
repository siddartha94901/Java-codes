package arrays;

public class ArrayJava {
	
	public static void main(String[]args)
	{
		String []s= {"siddarth","sid","siddu","siddarth"};
		for(int i=0;i<s.length;i++)
		{
			System.out.println(s[i]);
		}
	}

}
