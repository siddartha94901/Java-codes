package arrays;

public class FirstArray {
	//rev m
public static void main(String[] args) {
	
	int a=322942;
	

}}
