package arrays;
import java.util.*;

public class MaxArray {
	public static void main(String[]args)
	{
		int a[]= {1,2,3,4,5,6,7,8,9};
	Scanner s=new Scanner(System.in);
	int max=a[0];
	if(a[0]>max)
	{
		System.out.print(max);
		
	}
	}

}
