package arrays;

import java.util.*;

public class ElementFind {
	public static void main(String[] args) {

		Scanner s = new Scanner(System.in);
		int a[] = { 1, 2, 4, 5, 6, 7, 7, 8, 9, 2, 1, 10 };
		System.out.println("enter key");
		int key = s.nextInt();
		for (int i = 0; i < a.length; i++)

		{
			if (key == a[i]) {
				System.out.println("available");
				System.exit(0);
			}

			else {
				System.out.print("unavailable");
				System.exit(0);
			}

		}
	}
}
