package inheritance;

public class Exc {
public static void main(String[]args) {
	try {
		int a[]= {1,2,3,3,4};
		System.out.println(1/0);
		System.out.println(a[7]);
		
	
	}
	catch(ArithmeticException e){
		System.out.println("hol");
	}
	
	 catch (ArrayIndexOutOfBoundsException e) { System.out.println("array index"); }
	}
}
