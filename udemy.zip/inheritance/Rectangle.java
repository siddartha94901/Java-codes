package inheritance;

public class Rectangle {
    private int length, bredth;

    public Rectangle(int l, int b) {
        length = l;
        bredth = b;
    }

    public int getLength() {
        return length;
    }

    public int getBredth() {
        return bredth;
    }

    public void setLength(int L) {
        length = L;
    }

    public void setBredth(int B) {
        bredth = B;
    }

    public void area() {
        int a;
        a = length * bredth;
        System.out.println("Area: " + a);
    }

    public void perimeter() {
        int p;
        p = 2 * (length + bredth);
        System.out.println("Perimeter: " + p);
    }
}

class Cube extends Rectangle {
    private int height;

    public Cube(int l, int b, int h) {
        super(l, b); // Call the superclass constructor to initialize length and bredth
        height = h;
    }

    public int getHeight() {
        return height;
    }

    public void setHeight(int h) {
        height = h;
    }

    public void volume() {
        int v;
        v = getLength() * getBredth() * height;
        System.out.println("Volume: " + v);
    }
}

class Test {
    public static void main(String[] args) {
        Cube c = new Cube(15, 3, 38);
        c.area();
        c.volume();
    }
}
